import 'package:flutter/material.dart';
import 'package:netflix/screens/homepage.dart';

void main() {
  runApp(const MaterialApp(
    home: Home(),
  ));
}


