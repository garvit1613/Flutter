import 'package:flutter/material.dart';

import '../shared/widget/comingSoonSections.dart';
import '../shared/widget/myChip.dart';


class ComingSoon extends StatefulWidget {
  const ComingSoon({super.key});

  @override
  State<ComingSoon> createState() => _ComingSoonState();
}

class _ComingSoonState extends State<ComingSoon> {
  // define parameters which are only used in this context and will not be accessed from any other page or context
  int isSelected = 0;

  @override
  Widget build(BuildContext context) {
    return Stack(
        // alignment: AlignmentDirectional.center,
        children: [
          Positioned(
            top: 0,
            child: Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height * 0.08,
              padding: const EdgeInsets.symmetric(
                  // horizontal: 8,
                  vertical: 5),
              decoration: BoxDecoration(
                color: Colors.black,
              ),
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  GestureDetector(
                      onTap: () {
                        isSelected = 0;
                        setState(() {});
                      },
                      child: MyChip(selected: isSelected == 0 ? true : false)),
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.015,
                  ),
                  GestureDetector(
                    onTap: () {
                      isSelected = 1;
                      setState(() {});
                    },
                    child: MyChip(
                      selected: isSelected == 1 ? true : false,
                      icon: "🔥",
                      title: "Everyone's Watching",
                    ),
                  ),
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.015,
                  ),
                  GestureDetector(
                    onTap: () {
                      isSelected = 2;
                      setState(() {});
                    },
                    child: MyChip(
                      selected: isSelected == 2 ? true : false,
                      icon: "😁",
                      title: "Fast Laughs",
                    ),
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            top: MediaQuery.of(context).size.height * 0.08,
            child: Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height * 0.8,
              child: ListView(
                children: [
                  comingSoonSection(),
                  comingSoonSection(
                    mon: "September",
                    day: 1,
                    heroImage: "assets/BleachThousandYearsBloodWar.jpg",
                    logoImage: "assets/bleachLogo.png",
                    contentClass: "U/A",
                    ageCategory: "16+",
                    desc:
                        "Was it all just a coincidence, or was it inevitable? Ichigo Kurosaki gained the powers of a Soul Reaper through a chance encounter. As a Substitute Soul Reaper, Ichigo became caught in the turmoil of the Soul Society, a place where deceased souls gather.",
                    category: [
                      "Supernatural Shonen",
                      "Fantasy",
                      "Anime",
                      "Exciting"
                    ],
                  ),
                  comingSoonSection(
                    mon: "November",
                    day: 19,
                    heroImage: "assets/castlevania.jpg",
                    logoImage: "assets/castlevaniaLogo.png",
                    contentClass: "U/A",
                    ageCategory: "18+",
                    desc:
                        "The last surviving member of a disgraced clan fights to save Eastern Europe from Dracula. Inspired by the classic video game series.",
                    category: ["Action", "Fantasy", "Vampires", "Scary"],
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.04,
                  ),
                ],
              ),
            ),
          ),
        ]);
  }
}
