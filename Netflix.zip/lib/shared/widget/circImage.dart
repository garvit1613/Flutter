import 'package:flutter/material.dart';

class CircImage extends StatelessWidget {
  String imagePath = "assets/stranger_things.jpg";
  CircImage(this.imagePath, {super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 8.0, right: 8.0),
      child: CircleAvatar(
        backgroundImage: AssetImage(imagePath),
        radius: 50,
      ),
    );
  }
}
