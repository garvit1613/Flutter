import 'package:flutter/material.dart';
import 'package:netflix/shared/widget/roundCornersImage.dart';

class comingSoonSectionsImage extends StatelessWidget {
  String? imagePath;
  String? contentClass;
  String? ageCategory;
  comingSoonSectionsImage({
    this.imagePath = "assets/onePiece.png",
    this.contentClass = "U/A",
    this.ageCategory = "16+",
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(5),
      ),
      child: Stack(
        children: [
          // Image.asset(
          //   "assets/onePiece.png",
          //   fit: BoxFit.cover,
          // )
          RoundRectImage(
            imagePath: imagePath,
            section: "ComingSoonSections",
          ),
          Positioned(
            top: MediaQuery.of(context).size.height * 0.0175,
            right: MediaQuery.of(context).size.width * 0.0285,
            child: Container(
              width: 75,
              padding: EdgeInsets.symmetric(
                vertical: 4,
                horizontal: 4,
              ),
              decoration: BoxDecoration(
                color: Color.fromARGB(180, 0, 0, 0),
                borderRadius: BorderRadius.circular(5),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Text(
                    contentClass!,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    ageCategory!,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            bottom: MediaQuery.of(context).size.height * 0.001,
            right: MediaQuery.of(context).size.width * 0.025,
            child: Container(
              width: 24,
              clipBehavior: Clip.hardEdge,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Color.fromARGB(175, 0, 0, 0),
              ),
              child: IconButton(
                onPressed: () {},
                padding: EdgeInsets.all(1),
                icon: Icon(
                  Icons.volume_up_outlined,
                  color: Colors.white,
                  size: (20),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
