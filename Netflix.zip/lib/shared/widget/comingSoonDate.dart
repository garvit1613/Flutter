import 'package:flutter/material.dart';

class comingSoonDate extends StatelessWidget {
  String? mon;
  int? day;

  comingSoonDate({
    this.day = 31,
    this.mon = "AUG",
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      // color: Colors.blue,
      width: MediaQuery.of(context).size.width * 1 / 6,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "${mon!.toUpperCase()}",
            style: TextStyle(
                color: Color.fromARGB(255, 197, 197, 197),
                fontSize: 15,
                fontWeight: FontWeight.bold),
          ),
          SizedBox(
            height: 2,
          ),
          Text(
            """${day.toString().length == 1 ? "0${day}" : day}""",
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 40,
            ),
          ),
        ],
      ),
    );
  }
}
