import 'package:flutter/material.dart';

class comingSoonSectionCategory extends StatelessWidget {
  List<String> category;

  comingSoonSectionCategory({
    this.category = const [
      "Rousing",
      "Adventure",
      "Visualy Striking",
      "Pirates"
    ],
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(
        top: MediaQuery.of(context).size.height * 0.027,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            category[0],
            style: TextStyle(
              color: Color.fromARGB(255, 197, 197, 197),
              fontSize: MediaQuery.of(context).size.height * 0.022,
            ),
          ),
          Text(
            "*",
            style: TextStyle(
              color: Color.fromARGB(255, 197, 197, 197),
              fontSize: MediaQuery.of(context).size.height * 0.022,
            ),
          ),
          Text(
            category[1],
            style: TextStyle(
              color: Color.fromARGB(255, 197, 197, 197),
              fontSize: MediaQuery.of(context).size.height * 0.022,
            ),
          ),
          Text(
            "*",
            style: TextStyle(
              color: Color.fromARGB(255, 197, 197, 197),
              fontSize: MediaQuery.of(context).size.height * 0.022,
            ),
          ),
          Text(
            category[2],
            style: TextStyle(
              color: Color.fromARGB(255, 197, 197, 197),
              fontSize: MediaQuery.of(context).size.height * 0.022,
            ),
          ),
          Text(
            "*",
            style: TextStyle(
              color: Color.fromARGB(255, 197, 197, 197),
              fontSize: MediaQuery.of(context).size.height * 0.022,
            ),
          ),
          Text(
            category[3],
            style: TextStyle(
              color: Color.fromARGB(255, 197, 197, 197),
              fontSize: MediaQuery.of(context).size.height * 0.022,
            ),
          ),
        ],
      ),
    );
  }
}
