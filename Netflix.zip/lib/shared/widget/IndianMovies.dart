import 'package:flutter/material.dart';
import 'package:netflix/shared/widget/roundCornersImage.dart';


class Indian extends StatelessWidget {
  const Indian({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 8.0),
          child: Text(
            "Indian Movies",
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 20,
            ),
          ),
        ),
        Container(
          margin: EdgeInsets.only(top: 12.0, bottom: 12.0),
          // color: const Color.fromARGB(255, 47, 16, 16),
          height: 50 * 5,
          width: double.infinity,
          // color: Colors.amber[100],
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: [
              Row(
                children: [
                  RoundRectImage(
                      section: "indian", imagePath: "assets/bollywood1.jpg"),
                  RoundRectImage(
                      section: "indian", imagePath: "assets/bollywood2.jpg"),
                  RoundRectImage(
                      section: "indian", imagePath: "assets/bollywood3.jpg"),
                  RoundRectImage(
                      section: "indian", imagePath: "assets/bollywood4.jpg"),
                  RoundRectImage(
                      section: "indian", imagePath: "assets/bollywood5.jpg"),
                  RoundRectImage(
                      section: "indian", imagePath: "assets/bollywood6.jpg"),
                  RoundRectImage(
                      section: "indian", imagePath: "assets/bollywood7.jpg"),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}
