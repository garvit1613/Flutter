import 'package:flutter/material.dart';

class MoreSectionListTiles extends StatelessWidget {
  String? title;
  IconData? leadingIcon;
  IconData? trailingIcon;
  MoreSectionListTiles({
    this.leadingIcon = Icons.notifications_rounded,
    this.trailingIcon = Icons.arrow_forward_ios_rounded,
    this.title = "Notifications",
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      tileColor: const Color.fromARGB(255, 26, 26, 26),
      leading: Icon(
        leadingIcon,
        color: Colors.white,
      ),
      title: Text(
        title!,
        style: const TextStyle(
          color: Colors.white,
        ),
      ),
      trailing: Icon(
        trailingIcon,
        color: Colors.grey,
      ),
    );
  }
}
