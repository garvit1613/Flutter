import 'package:flutter/material.dart';
import 'package:netflix/screens/comingSoon.dart';
import 'package:netflix/screens/more.dart';
import 'package:netflix/shared/widget/preview.dart';
import 'IndianMovies.dart';
import 'myList.dart';
import 'nsStack.dart';
import 'originals.dart';


class TogglePage extends StatelessWidget {
  int currInd;

  List screens = [
    SingleChildScrollView(
      child: Container(
        color: Colors.black,
        width: double.infinity,
        // height: double.infinity,
        child: const Column(
          children: [
            MyStack(),
            Preview(),
            MyList(),
            Originals(),
            Indian(),
          ],
        ),
      ),
    ),
    Text(
      "Search",
      style: TextStyle(
          color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold),
    ),
    ComingSoon(),
    Text(
      "Downloads",
      style: TextStyle(
          color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold),
    ),
    More(),
  ];

  TogglePage({this.currInd = 0, super.key});

  @override
  Widget build(BuildContext context) {
    return screens[currInd];
  }
}
