import 'package:flutter/material.dart';

class comingSoonSectionDescription extends StatelessWidget {
  String? date;
  String? desc;
  comingSoonSectionDescription({
    this.date = "August 31",
    this.desc =
        "With his straw hat and ragtag crew, young pirate Monky D. Luffy goes on an epic voyage fpr treasure in this live-action adaptation of the popular manga.",
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      // height: MediaQuery.of(context).size.height * 0.2,
      margin: EdgeInsets.only(
        top: MediaQuery.of(context).size.height * 0.035,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Coming $date",
            style: TextStyle(
              color: Colors.white,
              fontSize: MediaQuery.of(context).size.height * 0.03,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(
            height: MediaQuery.of(context).size.height * 0.01,
          ),
          Text(
            desc!,
            style: TextStyle(
              color: Color.fromARGB(255, 197, 197, 197),
              fontSize: MediaQuery.of(context).size.height * 0.025,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}
